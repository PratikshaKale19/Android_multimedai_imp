#include "C2SoftX264Enc.h"
#include <log/log.h>
#include <C2Debug.h>
#include <media/stagefright/foundation/AMessage.h>

C2SoftX264Enc::C2SoftX264Enc(const std::shared_ptr<C2ComponentInterface>& intf)
    : SimpleC2Component(intf), mEncoder(nullptr) {
    x264_param_default_preset(&mParam, "veryfast", "zerolatency");
    x264_param_apply_profile(&mParam, "baseline");
    mParam.i_width = 1280;
    mParam.i_height = 720;
    mParam.i_fps_num = 30;
    mParam.i_fps_den = 1;
    mEncoder = x264_encoder_open(&mParam);
}

C2SoftX264Enc::~C2SoftX264Enc() {
    if (mEncoder) x264_encoder_close(mEncoder);
}

c2_status_t C2SoftX264Enc::onInit() {
    return C2_OK;
}

void C2SoftX264Enc::onStop() {
    if (mEncoder) {
        x264_encoder_close(mEncoder);
        mEncoder = nullptr;
    }
}

c2_status_t C2SoftX264Enc::onFlush_sm() {
    return C2_OK;
}

void C2SoftX264Enc::process(const std::unique_ptr<C2Work>& work, const std::shared_ptr<C2BlockPool>& pool) {
    if (!work || !mEncoder) return;

    const C2ConstLinearBlock inputBlock = work->input.buffers[0]->data().linearBlocks().front();
    const uint8_t *inData = inputBlock.map().get().data();

    x264_picture_t pic_in, pic_out;
    x264_picture_alloc(&pic_in, X264_CSP_I420, mParam.i_width, mParam.i_height);
    memcpy(pic_in.img.plane[0], inData, mParam.i_width * mParam.i_height * 3 / 2);

    x264_nal_t *nals;
    int i_nals;
    int frame_size = x264_encoder_encode(mEncoder, &nals, &i_nals, &pic_in, &pic_out);

    x264_picture_clean(&pic_in);

    if (frame_size > 0) {
        auto block = pool->fetchLinearBlock(frame_size).value();
        auto dst = block.map().get().data();
        memcpy(dst, nals[0].p_payload, frame_size);

        work->worklets.front()->output.configUpdate.clear();
        work->worklets.front()->output.flags = 0;
        work->worklets.front()->output.buffers.clear();
        work->worklets.front()->output.buffers.push_back(createLinearBuffer(block));
    }

    work->result = C2_OK;
    work->workletsProcessed = 1;
}
