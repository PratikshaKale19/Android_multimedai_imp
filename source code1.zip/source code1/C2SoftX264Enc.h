#ifndef C2_SOFT_X264_ENC_H
#define C2_SOFT_X264_ENC_H

#include <C2Component.h>
#include <C2Config.h>
#include <C2ParamDef.h>
#include <SimpleC2Component.h>

extern "C" {
#include <x264.h>
}

class C2SoftX264Enc : public SimpleC2Component {
public:
    C2SoftX264Enc(const std::shared_ptr<C2ComponentInterface>&);
    ~C2SoftX264Enc();

protected:
    c2_status_t onInit() override;
    void onStop() override;
    void process(const std::unique_ptr<C2Work>& work, const std::shared_ptr<C2BlockPool>& pool) override;
    c2_status_t onFlush_sm() override;

private:
    x264_t *mEncoder;
    x264_param_t mParam;
};

#endif
